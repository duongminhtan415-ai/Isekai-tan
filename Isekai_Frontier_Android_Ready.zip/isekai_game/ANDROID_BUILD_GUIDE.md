# Isekai Frontier - Android build

## Điều khiển điện thoại
- Joystick góc trái: di chuyển
- Kéo vùng bên phải: xoay camera
- ⚔: tấn công
- ↗: nhảy
- E: tương tác / thu thập

Project đã được thiết kế cho màn hình ngang 1280x720 và phát hiện mobile tự động.

## Xuất APK bằng Godot 4
1. Cài Godot 4.x và Android export templates.
2. Cài Android SDK + OpenJDK theo hướng dẫn Android của Godot.
3. Mở thư mục `isekai_game`.
4. Chọn Project > Export > Add > Android.
5. Chọn Landscape, rồi Export Project thành APK.

Nếu muốn đưa lên Google Play, dùng AAB thay vì APK và cấu hình keystore/release signing.

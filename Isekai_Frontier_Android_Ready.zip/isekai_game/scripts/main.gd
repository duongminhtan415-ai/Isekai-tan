extends Node3D

var player: CharacterBody3D
var camera: Camera3D
var yaw := 0.0
var pitch := -0.25
var health := 100.0
var max_health := 100.0
var energy := 100.0
var hunger := 100.0
var water := 100.0
var damage := 12.0
var level := 1
var xp := 0
var gold := 30
var wood := 0
var ore := 0
var fish := 0
var intro_time := 0.0
var intro_done := false
var enemies: Array[Node3D] = []
var npcs: Array[Node3D] = []
var ui: CanvasLayer
var stats_label: Label
var msg_label: Label
var mobile := false
var touch_move := Vector2.ZERO
var touch_look_id := -1
var touch_look_last := Vector2.ZERO
var mobile_attack := false
var mobile_interact := false
var mobile_jump := false

func _ready():
    mobile = OS.has_feature("mobile")
    _build_world()
    _build_player()
    _build_ui()
    if mobile: _build_mobile_controls()
    Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)

func _build_world():
    var env = WorldEnvironment.new()
    var e = Environment.new()
    e.background_mode = Environment.BG_COLOR
    e.background_color = Color(0.34,0.58,0.78)
    e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    e.ambient_light_color = Color(0.65,0.72,0.82)
    e.ambient_light_energy = 0.7
    env.environment = e
    add_child(env)
    var sun = DirectionalLight3D.new(); sun.rotation_degrees = Vector3(-55,-25,0); sun.light_energy=1.4; add_child(sun)
    var ground = StaticBody3D.new(); ground.name="WorldGround"; add_child(ground)
    var mesh = PlaneMesh.new(); mesh.size=Vector2(220,220); mesh.material=StandardMaterial3D.new(); mesh.material.albedo_color=Color(0.20,0.42,0.18); mesh.material.roughness=1.0
    var mi=MeshInstance3D.new(); mi.mesh=mesh; ground.add_child(mi)
    var col=CollisionShape3D.new(); var sh=BoxShape3D.new(); sh.size=Vector3(220,0.2,220); col.shape=sh; col.position.y=-0.1; ground.add_child(col)
    # village
    for i in range(7):
        _make_house(Vector3(-18 + (i%4)*9,0,-12 - (i/4)*9))
    for i in range(12):
        _make_tree(Vector3(-70 + (i*17)%130,0,-60 + (i*31)%110))
    for i in range(9):
        _make_rock(Vector3(25 + (i*19)%100,0,20 + (i*13)%80))
    for i in range(6):
        _spawn_enemy(Vector3(35+i*7,0,35+(i%3)*8), "Slime" if i%2==0 else "Goblin")
    for i in range(8):
        _spawn_npc(Vector3(-30+(i%4)*8,0,-5-(i/4)*8), i)
    # lake
    var lake=MeshInstance3D.new(); var lm=PlaneMesh.new(); lm.size=Vector2(38,28); var mat=StandardMaterial3D.new(); mat.albedo_color=Color(0.06,0.30,0.52); mat.metallic=0.1; mat.roughness=0.2; lm.material=mat; lake.mesh=lm; lake.position=Vector3(45,0.03,-35); add_child(lake)

func _make_house(p:Vector3):
    var b=MeshInstance3D.new(); var bm=BoxMesh.new(); bm.size=Vector3(7,4,6); var m=StandardMaterial3D.new(); m.albedo_color=Color(0.48,0.30,0.16); bm.material=m; b.mesh=bm; b.position=p+Vector3(0,2,0); add_child(b)
    var roof=MeshInstance3D.new(); var rm=PrismMesh.new(); rm.size=Vector3(8,2,7); rm.material=StandardMaterial3D.new(); rm.material.albedo_color=Color(0.28,0.12,0.07); roof.mesh=rm; roof.position=p+Vector3(0,5,0); roof.rotation_degrees.y=45; add_child(roof)

func _make_tree(p:Vector3):
    var root=Node3D.new(); root.position=p; add_child(root)
    var trunk=MeshInstance3D.new(); var c=CylinderMesh.new(); c.top_radius=.35; c.bottom_radius=.5; c.height=4; c.material=StandardMaterial3D.new(); c.material.albedo_color=Color(0.25,0.12,0.05); trunk.mesh=c; trunk.position.y=2; root.add_child(trunk)
    var leaves=MeshInstance3D.new(); var s=SphereMesh.new(); s.radius=2.2; s.height=4.4; s.material=StandardMaterial3D.new(); s.material.albedo_color=Color(0.08,0.32,0.09); leaves.mesh=s; leaves.position.y=4.8; root.add_child(leaves)

func _make_rock(p:Vector3):
    var r=MeshInstance3D.new(); var s=SphereMesh.new(); s.radius=1.3; s.height=2.0; s.material=StandardMaterial3D.new(); s.material.albedo_color=Color(0.25,0.27,0.29); r.mesh=s; r.position=p+Vector3(0,0.7,0); r.scale=Vector3(1.2,.7,.9); add_child(r)

func _spawn_enemy(p:Vector3, kind:String):
    var body=CharacterBody3D.new(); body.name=kind; body.position=p; add_child(body); enemies.append(body)
    var mi=MeshInstance3D.new(); var s=SphereMesh.new(); s.radius=1.1 if kind=="Slime" else .8; s.height=2.0 if kind=="Slime" else 1.7; var mat=StandardMaterial3D.new(); mat.albedo_color=Color(0.2,0.8,0.45) if kind=="Slime" else Color(0.35,0.5,0.22); s.material=mat; mi.mesh=s; mi.position.y=1; body.add_child(mi)
    var hp=Label3D.new(); hp.text=kind; hp.position=Vector3(0,2.5,0); hp.modulate=Color.WHITE; body.add_child(hp)

func _spawn_npc(p:Vector3, id:int):
    var body=CharacterBody3D.new(); body.position=p; body.name="Villager_%d"%id; add_child(body); npcs.append(body)
    var mi=MeshInstance3D.new(); var c=CapsuleMesh.new(); c.radius=.45; c.height=1.8; var mat=StandardMaterial3D.new(); mat.albedo_color=Color(0.25+id*.03,0.25,0.45); c.material=mat; mi.mesh=c; mi.position.y=.9; body.add_child(mi)
    var hp=Label3D.new(); hp.text="Dân làng"; hp.position=Vector3(0,2.2,0); body.add_child(hp)

func _build_player():
    player=CharacterBody3D.new(); player.name="Player"; player.position=Vector3(0,2,10); add_child(player)
    var capsule=CollisionShape3D.new(); var sh=CapsuleShape3D.new(); sh.radius=.45; sh.height=1.8; capsule.shape=sh; capsule.position.y=.9; player.add_child(capsule)
    var mi=MeshInstance3D.new(); var cm=CapsuleMesh.new(); cm.radius=.45; cm.height=1.8; cm.material=StandardMaterial3D.new(); cm.material.albedo_color=Color(0.8,0.8,0.9); mi.mesh=cm; mi.position.y=.9; player.add_child(mi)
    camera=Camera3D.new(); camera.position=Vector3(0,3.2,6); camera.rotation_degrees.x=-12; player.add_child(camera)
    camera.current=true

func _build_ui():
    ui=CanvasLayer.new(); add_child(ui)
    var panel=ColorRect.new(); panel.position=Vector2(18,18); panel.size=Vector2(310,170); panel.color=Color(0,0,0,.45); ui.add_child(panel)
    stats_label=Label.new(); stats_label.position=Vector2(30,28); stats_label.add_theme_font_size_override("font_size",20); ui.add_child(stats_label)
    msg_label=Label.new(); msg_label.position=Vector2(390,620); msg_label.add_theme_font_size_override("font_size",22); ui.add_child(msg_label)
    var help=Label.new(); help.text="WASD di chuyển • Chuột nhìn • Click đánh • E tương tác • Space nhảy"; help.position=Vector2(18,680); help.add_theme_font_size_override("font_size",16); ui.add_child(help)

func _unhandled_input(event):
    if event is InputEventMouseMotion and intro_done:
        yaw -= event.relative.x*0.003; pitch=clamp(pitch-event.relative.y*0.002,-1.1,0.5); player.rotation.y=yaw; camera.rotation.x=pitch
    if event.is_action_pressed("attack") and intro_done:
        energy=max(0,energy-8); _attack()
    if event.is_action_pressed("interact") and intro_done:
        _interact()
    if event is InputEventScreenTouch:
        if event.pressed and event.position.x > get_viewport().size.x * 0.48:
            touch_look_id = event.index
            touch_look_last = event.position
        elif not event.pressed and event.index == touch_look_id:
            touch_look_id = -1
    if event is InputEventScreenDrag and event.index == touch_look_id and intro_done:
        var delta_look = event.position - touch_look_last
        touch_look_last = event.position
        yaw -= delta_look.x * 0.006
        pitch = clamp(pitch - delta_look.y * 0.004, -1.1, 0.5)
        player.rotation.y = yaw
        camera.rotation.x = pitch

func _physics_process(delta):
    if not intro_done:
        intro_time += delta
        if intro_time>7.0:
            intro_done=true; msg_label.text="Bạn đã chuyển sinh! Hãy khám phá ngôi làng và vùng hoang dã."; Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)
        else:
            msg_label.text="CHUYỂN SINH...\n" + ("Một vụ tai nạn..." if intro_time<3 else "Ánh sáng bao trùm..." if intro_time<5 else "Thế giới mới đang mở ra...")
            return
    var dir=Vector3.ZERO
    if Input.is_action_pressed("move_forward") or touch_move.y < -0.25: dir-=player.global_transform.basis.z * max(1.0, -touch_move.y)
    if Input.is_action_pressed("move_back") or touch_move.y > 0.25: dir+=player.global_transform.basis.z * max(1.0, touch_move.y)
    if Input.is_action_pressed("move_left") or touch_move.x < -0.25: dir-=player.global_transform.basis.x * max(1.0, -touch_move.x)
    if Input.is_action_pressed("move_right") or touch_move.x > 0.25: dir+=player.global_transform.basis.x * max(1.0, touch_move.x)
    dir.y=0; dir=dir.normalized()
    player.velocity.x=dir.x*7; player.velocity.z=dir.z*7
    if not player.is_on_floor(): player.velocity.y-=20*delta
    elif Input.is_action_just_pressed("jump") or mobile_jump: player.velocity.y=8
    mobile_jump = false
    if mobile_attack:
        mobile_attack = false
        energy=max(0,energy-8); _attack()
    if mobile_interact:
        mobile_interact = false
        _interact()
    player.move_and_slide()
    hunger=max(0,hunger-delta*.7); water=max(0,water-delta*1.0)
    if hunger<=0 or water<=0: health=max(0,health-delta*3)
    for n in npcs:
        if is_instance_valid(n): n.position += Vector3(sin(Time.get_ticks_msec()/900.0+n.position.x)*.7,0,cos(Time.get_ticks_msec()/1100.0+n.position.z)*.7)*delta
    for e in enemies:
        if is_instance_valid(e) and e.global_position.distance_to(player.global_position)<14:
            var d=(player.global_position-e.global_position); d.y=0
            if d.length()>2.3: e.velocity=d.normalized()*1.4; e.move_and_slide()
    stats_label.text="LV %d  XP %d/100  Vàng %d\nHP %.0f/%.0f  DMG %.0f  EN %.0f\nĐói %.0f%%  Nước %.0f%%\nGỗ %d  Quặng %d  Cá %d"%[level,xp,gold,health,max_health,damage,energy,hunger,water,wood,ore,fish]

func _attack():
    for e in enemies:
        if is_instance_valid(e) and e.global_position.distance_to(player.global_position)<4:
            xp+=25; gold+=5; e.queue_free(); msg_label.text="Đánh bại quái vật! +25 XP, +5 vàng"; if xp>=100: level+=1; xp-=100; max_health+=15; health=max_health; damage+=4; msg_label.text="LEVEL UP! Chỉ số đã tăng."
            return
    msg_label.text="Không có mục tiêu trong tầm đánh."

func _interact():
    for n in npcs:
        if is_instance_valid(n) and n.global_position.distance_to(player.global_position)<4:
            gold+=0; msg_label.text="Dân làng: Chào mừng! Bạn có thể giao dịch và mua trang bị."
            return
    # nearby trees/rocks are simulated by gathering from the world
    if player.global_position.distance_to(Vector3(-18,0,-12))<15:
        wood+=2; msg_label.text="Thu thập gỗ +2"
    elif player.global_position.distance_to(Vector3(45,0,-35))<22:
        fish+=1; msg_label.text="Câu cá +1"
    else:
        ore+=1; msg_label.text="Đào khoáng sản +1"


func _make_mobile_button(parent: Control, text_value: String, pos: Vector2, size: Vector2, callback: Callable) -> Button:
    var b=Button.new()
    b.text=text_value
    b.position=pos
    b.size=size
    b.add_theme_font_size_override("font_size",26)
    b.modulate=Color(1,1,1,0.78)
    parent.add_child(b)
    b.button_down.connect(callback)
    return b

func _build_mobile_controls():
    var root=Control.new()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    root.mouse_filter=Control.MOUSE_FILTER_IGNORE
    ui.add_child(root)

    var joy=Control.new()
    joy.position=Vector2(28,500)
    joy.size=Vector2(230,190)
    joy.mouse_filter=Control.MOUSE_FILTER_STOP
    root.add_child(joy)
    var base=ColorRect.new()
    base.position=Vector2(10,10); base.size=Vector2(170,170); base.color=Color(0,0,0,0.25)
    base.mouse_filter=Control.MOUSE_FILTER_IGNORE; joy.add_child(base)
    var knob=Button.new()
    knob.text="●"; knob.position=Vector2(65,65); knob.size=Vector2(70,70)
    knob.add_theme_font_size_override("font_size",34); knob.modulate=Color(1,1,1,0.75)
    joy.add_child(knob)
    joy.gui_input.connect(func(ev):
        if ev is InputEventScreenTouch:
            if ev.pressed: touch_move=Vector2.ZERO
            else: touch_move=Vector2.ZERO
        elif ev is InputEventScreenDrag:
            var center=Vector2(95,95)
            touch_move=(ev.position-center)/70.0
            touch_move=touch_move.limit_length(1.0)
            knob.position=Vector2(60,60)+touch_move*55.0
    )

    _make_mobile_button(root,"⚔",Vector2(1060,505),Vector2(115,90),func(): mobile_attack=true)
    _make_mobile_button(root,"↗",Vector2(1180,505),Vector2(75,75),func(): mobile_jump=true)
    _make_mobile_button(root,"E",Vector2(1060,610),Vector2(115,75),func(): mobile_interact=true)
    var hint=Label.new()
    hint.text="Kéo bên phải để xoay camera"
    hint.position=Vector2(870,675)
    hint.add_theme_font_size_override("font_size",16)
    root.add_child(hint)
